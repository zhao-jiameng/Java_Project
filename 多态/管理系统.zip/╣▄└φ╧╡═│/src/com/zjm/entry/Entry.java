package com.zjm.entry;

import com.zjm.controller.Hello;

public class Entry {
    public static void main(String[] args) throws ClassNotFoundException {
        Hello.hello();
    }
}
